# WAB Backup Restore Instructions
# Generated: 2026-04-08T06:45:39.956Z
# Server: wt.visaway.co.uk

## Prerequisites
- Node.js 18+
- MongoDB 6+
- MySQL 8+
- Nginx
- PM2 (npm i -g pm2)

## Steps to restore on a new server:

### 1. Clone the repository
git clone <your-repo-url> /home/ubuntu/WAB
cd /home/ubuntu/WAB

### 2. Restore environment files
cp .env /home/ubuntu/WAB/.env
cp chatclone-react.env /home/ubuntu/WAB/chatclone-react/.env
# Edit .env to update:
#   - MONGODB_URI (if different host)
#   - MYSQL_HOST, MYSQL_USER, MYSQL_PASSWORD
#   - CLIENT_URL (new domain)
#   - WA_WEBHOOK_VERIFY_TOKEN
#   - JWT_SECRET

### 3. Restore MongoDB
mongorestore --uri="mongodb://localhost:27017" mongodb/

### 4. Restore MySQL
mysql -u <user> -p <database> < mysql-dump.sql

### 5. Restore uploads
cp -r uploads/ /home/ubuntu/WAB/server/uploads/

### 6. Install dependencies and build
cd /home/ubuntu/WAB
npm install
npm run build

### 7. Configure Nginx
# Copy and edit nginx.conf with your new domain
sudo cp nginx.conf /etc/nginx/sites-available/wab
sudo ln -s /etc/nginx/sites-available/wab /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

### 8. Set up SSL (Let's Encrypt)
sudo certbot --nginx -d your-new-domain.com

### 9. Start with PM2
pm2 start ecosystem.config.cjs
pm2 save
pm2 startup

### 10. Update WhatsApp webhook URL
# Go to Meta Developer Console > WhatsApp > Configuration
# Update the webhook URL to: https://your-new-domain.com/api/webhook
